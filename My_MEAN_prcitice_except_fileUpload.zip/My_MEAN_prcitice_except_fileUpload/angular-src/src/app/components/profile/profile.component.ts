import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { NgFlashMessageService } from 'ng-flash-messages';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  user: Object = {
    userId: ""
  };

  constructor(
    private authService: AuthService,
    private router: Router,
    private flashMessage: NgFlashMessageService
  ) { }

  ngOnInit() {
    this.authService.getProfile().subscribe(profile => {
      console.log(profile);
      if (profile.success) {
        this.user = profile.user;
      } else {
        this.authService.logout();
        this.flashMessage.showFlashMessage({
          messages: [profile.message],
          dismissible: true,
          timeout: 3000,
          type: 'success'
        });
        this.router.navigate(['/login']);
        return false;
      }
    },
      err => {
        console.log(err);
        return false;
      });
  }

}
