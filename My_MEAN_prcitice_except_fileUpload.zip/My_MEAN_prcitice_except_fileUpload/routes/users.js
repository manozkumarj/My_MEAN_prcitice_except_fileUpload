const express = require("express");
const User = require("../models/user");
const bodyParser = require("body-parser");
const router = express.Router();
const path = require("path");
const jwt = require("jsonwebtoken");

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

router.get("/", (req, res) => {
    res.render("fileUpload");
    /*    res.json({
            page: "Main root of /Users",
            msg: "Welcome Main root profile file"
        });*/
});


router.get("/profile", (req, res) => {
    res.json({
        page: "profile of /Users",
        msg: "Welcome to profile file"
    });
});


module.exports = router;